# Onde Foi Meu Dinheiro

Aplicativo de finanças pessoais para jovens adultos que desejam registrar gastos com menos esforço e compreender o destino do dinheiro ao longo do mês.

**Proposta:** escrever uma despesa em linguagem natural ou fotografar um cupom, revisar os dados interpretados pela IA e confirmar o lançamento. Receitas, histórico, orçamento por categoria e comparação mensal completam a experiência.

## Equipe

- Cecília Scharnovski
- Hellen Caroline
- Jonathan Silva Machado
- Nicolas da Gama

UTFPR, Campus Dois Vizinhos · Bacharelado em Engenharia de Software · Programação para Dispositivos Móveis · Prof. Dr. Marlon Marcon · 2026/2.

## Situação do projeto

Primeira entrega em preparação, com documentação e protótipo navegável local. O PRD foi autorizado como base para continuar a prototipação. Há dez telas conectadas, dados fictícios e cenários de falha; autenticação, câmera, IA e sincronização são simuladas. A implementação React Native com Expo pertence às etapas seguintes.

**Abra o [protótipo independente](output/Onde-Foi-Meu-Dinheiro-Prototipo.html) no navegador** ou use [prototipo/index.html](prototipo/index.html), mantendo seus arquivos vizinhos. O [pacote ZIP](output/Onde-Foi-Meu-Dinheiro-Entrega-01.zip) reúne documentação, protótipo e fontes. Extraia o ZIP antes de abrir.

| Etapa | Prazo informado no enunciado | Resultado esperado |
|---|---|---|
| 1 · Concepção e protótipos | 28/09/2026 | Tema, GitHub, PRD, decisões de arquitetura, protótipo navegável e diário de IA |
| 2 · Telas | 30/10/2026 | Telas implementadas, navegação e persistência local |
| 3 · Aplicativo final | 30/11/2026 | Autenticação, dados remotos, API, câmera e IA funcionais |

As entregas são pelo Moodle até 23h59, com apresentação presencial de 10 minutos por grupo. As datas foram transcritas do enunciado; mudanças comunicadas em aula devem ser incorporadas pela equipe.

## Documentação

- [PRD: requisitos, regras e escopo](docs/PRD.md)
- [Decisões de arquitetura propostas](docs/DECISOES-ARQUITETURA.md)
- [Diário de bordo de uso de IA](docs/DIARIO-DE-BORDO.md)
- [Checklist da primeira entrega](docs/ENTREGA-01.md)
- [Guia do protótipo e roteiro de exploração](docs/GUIA-DO-PROTOTIPO.md)
- [Plano de execução do protótipo](docs/PLANO-PROTOTIPO.md)

## Experiência principal

Início → Novo lançamento → Texto ou foto → Revisão dos campos → Confirmação → Histórico e orçamento atualizados.

A IA sugere os dados; o usuário confirma o que será registrado. O formulário manual permanece disponível quando a câmera ou o serviço de IA não puderem ser usados.

## Organização do trabalho

Quatro frentes propostas: produto e requisitos; experiência e interface; arquitetura e dados; integração e entrega. A distribuição nominal será combinada pela equipe. Todos devem revisar o conjunto e compreender as decisões apresentadas.

## Execução

O protótipo HTML abre por duplo clique e não requer instalação. Inicia em uma conta fictícia para exploração; toque em **AL → Sair da demonstração** para acessar login e cadastro. Recarregar restaura os dados. No celular, o painel de cenários fica abaixo do aplicativo.

Os dados têm data de referência **25/09/2026**. Use os exemplos apresentados; a interpretação de texto é uma simulação local limitada, sem chamadas de IA reais.

Para executar os seis testes do modelo, com Node.js instalado: `node --test prototipo/model.test.cjs`.

Para regenerar HTML independente e ZIP, com Python instalado: `python scripts/build_delivery.py`.

Publicação no GitHub, confirmação da reserva do tema e submissão no Moodle permanecem pendentes. Não há remoto configurado nesta versão.

## Referências do trabalho

- **Trabalho React Native 2026_2.pdf**, p. 1–4: requisitos gerais, entregas e critérios de avaliação.
- **temas.pdf**, p. 7, tema 9: problema, público, funcionalidades e diferencial de Onde Foi Meu Dinheiro.

Os documentos da disciplina orientam os requisitos acadêmicos. As escolhas de produto e arquitetura são identificadas nos documentos como propostas da equipe, sem atribuí-las ao professor.
